function getArticles() {
  var articles = [  {"name": "eliminar cuenta de correo","id": "eliminar_cuenta_de_correo","category": "articles","url": "articles/article_secondArticle.html"},
  {"name": "a�adir una cuenta de correo","id": "a�adir_una_cuenta_de_correo","category": "articles","url": "articles/article_firstArticle.html"},
  {"name": "agenda","id": "agenda","category": "articles","url": "articles/article_agenda.html"}]
  return articles;
}